from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StructField, StringType, FloatType, IntegerType

POSTGRES_URL = 'jdbc:postgresql://172.18.0.5:5432/patinetes'
POSTGRES_USER = 'pisd'
POSTGRES_PASSWORD = 'pisd'
POSTGRES_TABLE = 'patinetes_data'

KAFKA_HOST = '172.18.0.4:9092'
KAFKA_TOPIC = 'patinetes_tr'

def filter_df(df):
    # Filtra los datos para incluir solo aquellos que cumplen con ciertos criterios.
    # Por ejemplo, filtra patinetes con velocidad superior a un umbral.
    filtered_df = df.select("content.*").filter((col("price") < 100) & (col("vel") <= 20.0) & (col("tt") <= 5000) & (col("dis") >= 300))
    return filtered_df

def write_to_postgres(writeDF, epoch_id):
    writeDF.write \
        .jdbc(url=POSTGRES_URL,
              table=POSTGRES_TABLE,
              mode="append",  
              properties={"user": POSTGRES_USER, "password": POSTGRES_PASSWORD, "driver": "org.postgresql.Driver"})

if __name__ == "__main__":
    spark = SparkSession.builder.master("spark://spark-master:7077").appName("SparkStreamingKafkaConsumer").getOrCreate()

    # Define el esquema para los datos que se esperan desde Kafka
    schema = StructType([
        StructField("idS", StringType(), False),
        StructField("tsO", StringType(), False),
        StructField("tsD", StringType(), False),
        StructField("price", FloatType(), False),
        StructField("tt", IntegerType(), False),
        StructField("dis", FloatType(), False),
        StructField("vel", FloatType(), False),
        StructField("lonO", FloatType(), False),
        StructField("latO", FloatType(), False),
        StructField("lonD", FloatType(), False),
        StructField("latD", FloatType(), False),
    ])

    # Lee los datos desde Kafka
    kafka_stream_df = spark.readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_HOST) \
        .option("subscribe", KAFKA_TOPIC) \
        .option("startingOffsets", "earliest") \
        .load()

    # Convierte los datos en formato JSON y aplica el esquema
    value_json = kafka_stream_df.select(from_json(col("value").cast("string"), schema).alias("content"))

    filtered_data = filter_df(value_json)

    # Escribe en PostgreSQL directamente usando .write.jdbc
    query = filtered_data.writeStream \
        .outputMode("update") \
        .foreachBatch(write_to_postgres) \
        .start()

    # Espera a que la consulta finalice
    query.awaitTermination()

