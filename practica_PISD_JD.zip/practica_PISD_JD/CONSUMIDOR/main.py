from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

# Configuración de Spark
spark = SparkSession.builder \
    .appName("KafkaToPostgres") \
    .getOrCreate()

# Define el esquema para los datos de Kafka
schema = StructType([
    StructField("idS", StringType(), True),
    StructField("tsO", StringType(), True),
    StructField("tsD", StringType(), True),
    StructField("price", DoubleType(), True),
    StructField("tt", StringType(), True),
    StructField("dis", DoubleType(), True),
    StructField("vel", DoubleType(), True),
    StructField("lonO", DoubleType(), True),
    StructField("latO", DoubleType(), True),
    StructField("lonD", DoubleType(), True),
    StructField("latD", DoubleType(), True)
])

# Lee datos desde Kafka
kafka_df = spark \
    .readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "kafka:9092") \
    .option("subscribe", "patinetes_tr") \
    .load()

# Convierte el valor de Kafka (JSON) a columnas
parsed_df = kafka_df \
    .selectExpr("CAST(value AS STRING)") \
    .select(from_json("value", schema).alias("data")) \
    .select("data.*")

# Escribe los datos a PostgreSQL
query = parsed_df \
    .writeStream \
    .foreachBatch(lambda batch_df, batch_id: batch_df.write.jdbc(
        url="jdbc:postgresql://postgres:5432/patinetes",
        table="patinetes_data",
        mode="append",
        properties={"user": "pisd", "password": "pisd"}
    )) \
    .start()

# Espera que el streaming termine
query.awaitTermination()

