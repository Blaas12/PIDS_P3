from confluent_kafka import Producer
import time
import json
import random
from datetime import datetime, timedelta

# Configuración del productor Kafka
kafka_broker = 'kafka:9092'
kafka_topic = 'patinetes_tr'

conf = {'bootstrap.servers': kafka_broker}

producer = Producer(conf)

def delivery_report(err, msg):
    """Callback called on producing completion or failure."""
    if err is not None:
        print('Message delivery failed: {}'.format(err))
    else:
        print('Message delivered to {} [{}]'.format(msg.topic(), msg.partition()))

def generate_random_data():
    # Genera datos aleatorios de patinetes
    idS = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=4))
    tsO = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    tsD = (datetime.now() + timedelta(minutes=random.randint(5, 30))).strftime("%d/%m/%Y %H:%M:%S")
    price = round(random.uniform(1.0, 5.0), 4)
    tt = random.randint(400, 800)
    dis = round(random.uniform(1000, 2000), 4)
    vel = round(random.uniform(10, 20), 4)
    lonO = round(random.uniform(12.4, 12.5), 6)
    latO = round(random.uniform(41.85, 41.87), 6)
    lonD = round(random.uniform(12.46, 12.47), 6)
    latD = round(random.uniform(41.85, 41.87), 6)

    data = {
        'idS': idS,
        'tsO': tsO,
        'tsD': tsD,
        'price': price,
        'tt': tt,
        'dis': dis,
        'vel': vel,
        'lonO': lonO,
        'latO': latO,
        'lonD': lonD,
        'latD': latD
    }

    return json.dumps(data)

# Envía datos al tema Kafka
try:
    while True:
        data = generate_random_data()
        producer.produce(kafka_topic, key='key', value=data, callback=delivery_report)
        producer.poll(0)  # Espera para permitir que el callback se llame
        time.sleep(60)  # Espera 1 segundo entre la generación de datos
except KeyboardInterrupt:
    pass

# Limpia y cierra el productor
producer.flush()

