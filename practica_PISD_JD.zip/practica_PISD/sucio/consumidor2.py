from pyspark.sql import SparkSession
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
import json

def process_stream(rdd):
    # Ejemplo: Imprimir la cantidad de elementos en cada RDD
    print("Número de elementos en el RDD actual:", rdd.count())
    
    # Agregar aquí cualquier otra lógica de procesamiento deseada


spark = SparkSession.builder.appName("KafkaSparkStreaming").getOrCreate()
ssc = StreamingContext(spark.sparkContext, 10)  # Intervalo de 10 segundos

kafka_params = {"bootstrap.servers": "kafka:9092"}
kafka_topic = ["patinetes_tr"]

kafka_stream = KafkaUtils.createDirectStream(ssc, kafka_topic, kafka_params)
parsed_stream = kafka_stream.map(lambda x: json.loads(x[1]))

parsed_stream.foreachRDD(process_stream)

ssc.start()
ssc.awaitTermination()

