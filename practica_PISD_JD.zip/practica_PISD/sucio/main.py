from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType

# Configuración de Spark
spark = SparkSession.builder.appName("KafkaSparkStreamingConsumer").getOrCreate()

# Define el esquema para los datos de Kafka
schema = StructType([
    StructField("idS", StringType(), True),
    StructField("tsO", StringType(), True),
    StructField("tsD", StringType(), True),
    StructField("price", DoubleType(), True),
    StructField("tt", IntegerType(), True),
    StructField("dis", DoubleType(), True),
    StructField("vel", DoubleType(), True),
    StructField("lonO", DoubleType(), True),
    StructField("latO", DoubleType(), True),
    StructField("lonD", DoubleType(), True),
    StructField("latD", DoubleType(), True)
])

# Lee datos desde Kafka
df = spark \
    .readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "kafka:9092") \
    .option("subscribe", "patinetes_tr") \
    .load()

# Convierte los datos en formato JSON
df_json = df.selectExpr("CAST(value AS STRING)").select(from_json("value", schema).alias("data")).select("data.*")

# Realiza cualquier operación de procesamiento o análisis necesario
# (Por ejemplo, puedes imprimir los datos en la consola)
query = df_json \
    .writeStream \
    .outputMode("append") \
    .format("console") \
    .start()

# Espera que la transmisión de Spark se complete
query.awaitTermination()



