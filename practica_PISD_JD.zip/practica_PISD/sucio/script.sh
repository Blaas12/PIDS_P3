#!/bin/bash

# Obtener el ID del contenedor spark-master
container_id=$(sudo docker ps -qf "name=spark-master")

# Verificar si el contenedor está en ejecución
if [ -n "$container_id" ]; then
  echo "Ejecutando spark-submit dentro del contenedor spark-master..."
  
  # Esperar 30 segundos (ajusta según tus necesidades)
  sleep 15

  # Ejecutar spark-submit dentro del contenedor
  sudo docker exec -it "$container_id" /spark/bin/spark-submit /opt/app/consumidor.py
else
  echo "Error: El contenedor spark-master no está en ejecución."
fi

