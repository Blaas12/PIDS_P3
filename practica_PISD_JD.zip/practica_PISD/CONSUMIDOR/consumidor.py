from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StructField, StringType, FloatType, IntegerType

KAFKA_HOST = 'kafka:9092'
KAFKA_TOPIC = 'patinetes_tr'

def filter_df(df):
    # Filtra los datos para incluir solo aquellos que cumplen con ciertos criterios.
    # Por ejemplo, filtra patinetes con velocidad superior a un umbral.

    filtered_df = df.select("content.*").filter(col("vel") > 18.0)

    return filtered_df

def display_aggregation(df):
    query = df.writeStream \
        .outputMode("append") \
        .format("console") \
        .trigger(processingTime="25 seconds") \
        .start()

    query.awaitTermination()

if __name__ == "__main__":
    spark = SparkSession.builder.appName("SparkStreamingKafkaConsumer").getOrCreate()

    # Define el esquema para los datos que se esperan desde Kafka
    schema = StructType([
        StructField("idS", StringType(), False),
        StructField("tsO", StringType(), False),
        StructField("tsD", StringType(), False),
        StructField("price", FloatType(), False),
        StructField("tt", IntegerType(), False),
        StructField("dis", FloatType(), False),
        StructField("vel", FloatType(), False),
        StructField("lonO", FloatType(), False),
        StructField("latO", FloatType(), False),
        StructField("lonD", FloatType(), False),
        StructField("latD", FloatType(), False),
    ])

    # Lee los datos desde Kafka
    kafka_stream_df = spark.readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_HOST) \
        .option("subscribe", KAFKA_TOPIC) \
        .option("startingOffsets", "earliest") \
        .load()

    # Convierte los datos en formato JSON y aplica el esquema
    value_json = kafka_stream_df.select(from_json(col("value").cast("string"), schema).alias("content"))
    filtered_data = filter_df(value_json)

    # Muestra la agregación en la consola (puedes personalizar esto según tus necesidades)
    display_aggregation(filtered_data)

