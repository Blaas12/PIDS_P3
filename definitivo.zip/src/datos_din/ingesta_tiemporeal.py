import csv
from confluent_kafka import Producer, admin
import time
import random
from datetime import datetime, timedelta
import time

time.sleep(10)

# Kafka Configuration
kafka_conf = {
    'bootstrap.servers': 'kafka:9092',  # Kafka bootstrap servers
}

# Kafka Topic
kafka_topic = 'main_flow'

# Initialize Kafka Producer
producer = Producer(kafka_conf)

def generate_random_data():
    # Generate random scooter journey data
    idS = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=4))
    tsO = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    tsD = (datetime.now() + timedelta(minutes=random.randint(5, 30))).strftime("%d/%m/%Y %H:%M:%S")
    price = round(random.uniform(1.0, 120.0), 2)
    tt = random.randint(400, 800)
    dis = round(random.uniform(1000, 2000), 3)
    vel = round(random.uniform(10, 20), 4)
    lonO = round(random.uniform(12.4, 12.5), 6)
    latO = round(random.uniform(41.85, 41.87), 6)
    lonD = round(random.uniform(12.46, 12.47), 6)
    latD = round(random.uniform(41.85, 41.87), 6)

    data = [idS, tsO, tsD, price, tt, dis, vel, lonO, latO, lonD, latD]
    return data

try:
    while True:
        data = generate_random_data()
        producer.produce(kafka_topic, value=str(data))
        print(f"Producing message {datetime.now()} Message:\n{str(data)}")
        time.sleep(3)  # Wait for 3 seconds between data generation
except KeyboardInterrupt:
    pass

# Ensure any remaining messages are sent before closing
producer.flush()
producer.close()





