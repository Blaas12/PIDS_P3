from pyspark.sql import SparkSession
from pyspark.sql.functions import expr
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, FloatType, IntegerType

# Configuración de Spark
spark = SparkSession.builder \
    .appName("Spark-Kafka-Consumer") \
    .config("spark.jars", "/app/postgresql-42.7.0.jar") \
    .config("spark.jars.packages", "io.delta:delta-core_2.12:1.0.0") \
    .getOrCreate()

# Configuración de conexión a Kafka
kafka_bootstrap_servers = "kafka:9092"
kafka_topic = "main_flow"

# Definición del esquema para los datos de Kafka
schema = StructType([
    StructField("idS", StringType(), False),
    StructField("tsO", StringType(), False),
    StructField("tsD", StringType(), False),
    StructField("price", FloatType(), False),
    StructField("tt", FloatType(), False),
    StructField("dis", IntegerType(), False),
    StructField("vel", FloatType(), False),
    StructField("lonO", FloatType(), False),
    StructField("latO", FloatType(), False),
    StructField("latD", FloatType(), False),
    StructField("lonD", FloatType(), False)
])

# Lectura de datos desde Kafka como CSV
df = spark \
    .readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", kafka_bootstrap_servers) \
    .option("subscribe", kafka_topic) \
    .load() \
    .selectExpr("CAST(value AS STRING)")

# Parse the CSV values into separate columns using the defined schema
parsed_df = df.select(expr("split(value, ',')").alias("csv_values")) \
    .selectExpr(
        "csv_values[0] as idS",
        "csv_values[1] as tsO",
        "csv_values[2] as tsD",
        "cast(csv_values[3] as float) as price",
        "cast(csv_values[4] as float) as tt",
        "cast(csv_values[5] as int) as dis",
        "cast(csv_values[6] as float) as vel",
        "cast(csv_values[7] as float) as lonO",
        "cast(csv_values[8] as float) as latO",
        "cast(csv_values[9] as float) as latD",
        "cast(csv_values[10] as float) as lonD"
    )

# Print the schema of the DataFrame
parsed_df.printSchema()

# Configuración de conexión a la base de datos PostgreSQL
postgres_url = "jdbc:postgresql://postgres-container:5432/postgres"
postgres_properties = {
    "user": "postgres",
    "password": "pids",
    "driver": "org.postgresql.Driver"
}

# Escritura de datos filtrados en la tabla de PostgreSQL
query = parsed_df \
    .writeStream \
    .foreachBatch(lambda batch_df, batch_id: batch_df.write.jdbc(postgres_url, "patinetes", mode="append", properties=postgres_properties)) \
    .outputMode("update") \
    .start()

# Espera a que la consulta termine (puedes ajustar el tiempo según tus necesidades)
query.awaitTermination()
